package arthmeticCalulator;

import java.util.Scanner;

public class Calculator {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
 
        System.out.print("Enter the first number: ");
        int firstNumber = sc.nextInt();
        System.out.print("Enter the second number: ");
        int secondNumber = sc.nextInt();
 
        System.out.print("Enter the type of operation you want to perform (+, -, *, /, %): ");
        String operation = sc.next();
        performOperation(firstNumber, secondNumber, operation);
        
    }
 
    public static void performOperation(int firstNumber, int secondNumber, String operation) {
        String result ;
        int res=0;
        switch (operation) {
            case "+":
               res = firstNumber + secondNumber;
               System.out.println("Your answer is: " + res);
                break;
            case "-":
                res = firstNumber - secondNumber;
                System.out.println("Your answer is: " + res);
                break;
            case "*":
                res = firstNumber * secondNumber;
                System.out.println("Your answer is: " + res);
                break;
            case "%":
            	if (secondNumber ==0 ) {
                	result = "Invalid opration";
                	System.out.println("Your answer is: " + result);
                	break;
                	}
                	else
                	{
                res = firstNumber % secondNumber;
                System.out.println("Your answer is: " + res);
                break;}
            case "/":
            	if (secondNumber ==0 ) {
            	result = "Invalid opration";
            	System.out.println("Your answer is: " + result);
            	break;
            	}
            	else {
                res = firstNumber / secondNumber;
                System.out.println("Your answer is: " + res);
                break;
                }
            default:
                System.out.println("Invalid operation");
                break;
        }
       
        
    }
}