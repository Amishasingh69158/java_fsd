package Practice;


interface Interface1  
{  
public default void display()   
{  
System.out.println("In method of Interface1 ");  
}  
}  
interface Interface2  
{  
public default void display()   
{  
System.out.println("In method of Interface2 ");  
}  
}  
public class DimondsProblem  implements Interface1, Interface2  
{  
public void display()   
{  
	Interface1.super.display();  
   Interface2.super.display();  
}  
public static void main(String args[])   
{  
	DimondsProblem obj = new DimondsProblem();  
obj.display();  
}  
}  