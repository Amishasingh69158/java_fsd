package Practice;
import java.io.File;
import java.io.IOException;    
//import java.nio.channels.FileLock; 

public class FileCreateExample {


              public static void main(String args[]) {  
              try {  
                      // Creating an object of a file  
                      File f0 = new File("FileExample.txt");   
                      if (f0.createNewFile()) {  
                                 System.out.println("File " + f0.getName() + " created ");  
                      } else {  
                                 System.out.println("File is already exist ");  
                      }  
                    } catch (IOException exception) {  
                             System.out.println("An unexpected error is occurred.");  
                             exception.printStackTrace();  
                 }   
       }  
} 