class Toy{
	Toy()
	{System.out.println("Toy is sold");}
}
class Employee{
	//creating default constructor
	String name;
	int id;
	Employee(String name, int id){
		this.name=name;
		this.id=id;
	}
	//creating copy constructor
	Employee(Employee SetValue){
		this.name = SetValue.name;
		this.id = SetValue.id;
	}
}
public class ConstrouctorType {

	public static void main(String[] args) {
		//invoke a default constructor
		Toy setValue1 = new Toy();
		//invoke the parameterized constructor
		Employee setValue2= new Employee("Amisha",100);
		System.out.println("Employee Name: "+setValue2.name+"\n"+ "Employee Id: "+setValue2.id);
		//invoke the copy constructor
		Employee setValue3 = new Employee(setValue2);
		System.out.println("Employee Name: "+setValue3.name+"\n"+ "Employee Id: "+setValue3.id);
	}

}
