
public class MethodCalling {
	static void NoPassingParameterNoReturnType () {
		System.out.println("I am in no passing parameter and no return type  method");
	}
	
	static void PassingParameterNotReturnType(int a,int b) {
		System.out.println("I am in Passing parameter but not return type method"+" a="+a+" b="+b);
	}
	
	static int InPassingParameteReturnType(int a) {
		System.out.println("I am in Passing parameter and return type method"+ " a="+a);
		return 0;
	}

	public static void main(String[] args) {
		int a=1;
		int b=2;
		NoPassingParameterNoReturnType();
		PassingParameterNotReturnType(a,b);
		InPassingParameteReturnType(a);

	}

}
