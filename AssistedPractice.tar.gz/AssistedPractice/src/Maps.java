import java.util.Map;
import java.util.HashMap;

public class Maps { 
	   
    public static void main(String args[]) 
    { 
        // Creating an empty HashMap 
        Map<String, Integer> st 
            = new HashMap<String, Integer>(); 
  
        // Inserting pairs in above Map 
        // using put() method 
        st.put("amisha", new Integer(100)); 
        st.put("bhanu", new Integer(101)); 
        st.put("chintu", new Integer(102)); 
        st.put("doly", new Integer(103)); 
  
        // Traversing through Map using for-each loop 
        for (Map.Entry<String, Integer> st1 : 
             st.entrySet()) { 
  
            // Printing Student Details
        	System.out.println("Student Name and RollNo.: ");
            System.out.print(st1.getKey() + ":"); 
            System.out.println(st1.getValue()); 
        } 
    } 
}

