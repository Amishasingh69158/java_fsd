class Outer {
 
    // Method
    private static void outerMethod()
    {
        System.out.println("inside outerMethod");
    }
 
    // Static inner class
    static class Inner {
 
        public static void dis()
        {
            System.out.println("inside inner class Method");
 
            // Calling method inside main() method
            outerMethod();
        }
    }
}

public class InnerClass {

    public static void main(String args[])
    {
        // Calling method static dis method
        Outer.Inner.dis();
    }
}
