
public class AccessModifier {
    static void MethodIsDefault() {
		System.out.println("I am in default method");
	}
	
	
	static public void MethodIsPublic() {
		System.out.println("I am in public method");
	}
	
	static private void MethodIsPrivate() {
		System.out.println("I am in private method");
	}
	
	static protected void MethodIsProtected() {
		System.out.println("I am in protected method");

	}
	
	public static void main(String[] args) {
        MethodIsPublic();
        MethodIsPrivate();
        MethodIsProtected();
        MethodIsDefault();
	}

}
