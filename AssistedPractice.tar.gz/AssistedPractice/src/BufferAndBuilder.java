
public class BufferAndBuilder {

	public static void main(String[] args) {
		//StringBuffer is a peer class of String that provides much of the functionality of strings
		 StringBuffer buffer=new StringBuffer("Implement ");  
	        buffer.append("StringBuffer");  
	        System.out.println(buffer); 
	     //Similar to StringBuffer, the StringBuilder in Java represents a mutable sequence of characters
	     StringBuilder builder=new StringBuilder("Implement ");  
	        builder.append("StringBuilder");  
	        System.out.println(builder);

	}

}
