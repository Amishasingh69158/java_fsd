import java.util.Scanner;
public class ImplicitAndExplicit {
	
	public static void main(String[] args) {
		//Initialization of variable
		int number;
		System.out.println("Enter The number for type casting");
		//input the number
		Scanner sc = new Scanner(System.in);
	    number = sc.nextInt();
	    
	    //Implicit Type Casting
	    long numberInLong = number;
	    float numberInFloat = number;
	    double numberInDouble = number;
	    
	    System.out.println("number in int : " +number);

	    System.out.println("number in long : " +numberInLong);

	    System.out.println("number in float : " +numberInFloat);

	    System.out.println("number in Double : " +numberInDouble);
		
	    //Explicit Type Casting
	    byte numberInByte = (byte) number;
	    short numberInShort = (short) number;
	    char numberInChar = (char) number;
	    System.out.println("number in byte : " +numberInByte);
	    System.out.println("number in sort : " +numberInShort);
	    System.out.println("number in char : " +numberInChar);

		

	}
}
